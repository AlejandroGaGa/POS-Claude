"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { computeTotals, formatMoney, formatNumber, PAYMENT_LABELS, PAYMENT_METHODS, round2, type PaymentMethod } from "@/lib/pricing";
import { Alert, Button, Field, Input, cx } from "./ui";
import Icon from "./Icon";

export default function ConvertQuote({ id, subtotal, defaultPct }: { id: string; subtotal: number; defaultPct: number }) {
  const router = useRouter();
  const [method, setMethod] = useState<PaymentMethod | null>(null);
  const [pct, setPct] = useState(String(defaultPct));
  const [cash, setCash] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const pctNum = Number(pct.replace(",", "."));
  let totals = null;
  try {
    totals = computeTotals([{ subtotal }], method, method === "terminal" ? pctNum : 0);
  } catch {}
  const cashNum = Number(cash.replace(",", "."));
  const change = method === "efectivo" && cash !== "" && totals ? round2(cashNum - totals.total) : null;

  async function submit() {
    if (!method) return setError("Elige el método de pago.");
    setBusy(true);
    setError("");
    const res = await fetch(`/api/sales/${id}/convert`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ paymentMethod: method, commissionPct: method === "terminal" ? pctNum : 0, cashReceived: method === "efectivo" && cash !== "" ? cashNum : null }),
    });
    const data = await res.json();
    if (!res.ok) {
      setBusy(false);
      return setError(data.error);
    }
    router.push(`/notas/${data.id}?nuevo=1`);
  }

  return (
    <div className="flex flex-col gap-3">
      <fieldset>
        <legend className="mb-2 text-sm font-semibold text-muted">Método de pago</legend>
        <div className="grid grid-cols-3 gap-2">
          {PAYMENT_METHODS.map((m) => (
            <label key={m} className={cx("flex min-h-16 cursor-pointer flex-col items-center justify-center gap-1 rounded-2xl border px-1 text-center text-sm font-semibold transition-colors has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-focus", method === m ? "border-accent bg-accent text-accent-foreground" : "border-border hover:bg-surface-secondary")}>
              <input type="radio" name="cmethod" className="sr-only" checked={method === m} onChange={() => setMethod(m)} />
              <Icon name={m === "efectivo" ? "wallet" : m === "terminal" ? "card" : "cash"} className="size-5" />
              {m === "terminal" ? "Terminal" : PAYMENT_LABELS[m]}
            </label>
          ))}
        </div>
      </fieldset>
      {method === "terminal" && (
        <div className="rounded-2xl bg-warning-soft p-4 text-warning-soft-foreground">
          <Field label="Comisión por terminal (%)" htmlFor="cpct">
            <Input id="cpct" inputMode="decimal" value={pct} onChange={(e) => setPct(e.target.value)} />
          </Field>
        </div>
      )}
      {method === "efectivo" && (
        <Field label="Efectivo recibido (opcional)" htmlFor="ccash">
          <Input id="ccash" inputMode="decimal" value={cash} onChange={(e) => setCash(e.target.value)} />
        </Field>
      )}
      <dl className="flex flex-col gap-1 border-t border-dashed border-separator pt-3 tabular">
        <div className="flex justify-between">
          <dt>Subtotal</dt>
          <dd>{formatMoney(subtotal)}</dd>
        </div>
        {method === "terminal" && totals && (
          <div className="flex justify-between">
            <dt>Comisión ({formatNumber(totals.commissionPct, 2)}%)</dt>
            <dd>{formatMoney(totals.commissionAmount)}</dd>
          </div>
        )}
        <div className="flex items-baseline justify-between">
          <dt className="font-semibold">Total a cobrar</dt>
          <dd className="font-display text-3xl">{totals ? formatMoney(totals.total) : "—"}</dd>
        </div>
        {change !== null && Number.isFinite(change) && (
          <div className={cx("flex justify-between font-semibold", change < 0 ? "text-bad" : "text-ok")}>
            <dt>{change < 0 ? "Falta" : "Cambio"}</dt>
            <dd>{formatMoney(Math.abs(change))}</dd>
          </div>
        )}
      </dl>
      {error && <Alert>{error}</Alert>}
      <Button onClick={submit} disabled={busy || !method} className="min-h-12 text-base">
        {busy ? "Cobrando…" : "Cobrar y convertir en venta"}
      </Button>
    </div>
  );
}
