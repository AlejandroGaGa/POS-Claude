"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  availableModes,
  computeTotals,
  CUSTOMER_LABELS,
  CUSTOMER_TYPES,
  formatMoney,
  formatNumber,
  MAX_COMMISSION_PCT,
  PAYMENT_LABELS,
  PAYMENT_METHODS,
  priceLine,
  round2,
  type CustomerType,
  type PaymentMethod,
  type ProductPricing,
} from "@/lib/pricing";
import { priceSummary } from "@/lib/productSummary";
import type { ProductJSON } from "@/lib/types";
import { Alert, Button, Field, Input, Select, cx } from "../ui";
import Icon, { type IconName } from "../Icon";
import { SearchField } from "@heroui/react";
import AddItemDialog, { type CartLine } from "./AddItemDialog";

const CART_KEY = "hp_cart_v2";

const COLOR_ORDER = ["Blanco", "Natural", "Negro", "Champagne", "Nogal", "Natural brillante", "Bronce brillante", "Nogal cerezo"];
const colorRank = (c?: string) => {
  const i = COLOR_ORDER.indexOf(c ?? "");
  return i < 0 ? COLOR_ORDER.length : i;
};

/** Agrupa variantes (mismo `group`) en una sola tarjeta, respetando el orden de llegada; colores en el orden de la lista. */
function groupProducts(list: ProductJSON[]): ProductJSON[][] {
  const map = new Map<string, ProductJSON[]>();
  for (const p of list) {
    const k = p.group ? `g:${p.category}:${p.group}` : `p:${p._id}`;
    const arr = map.get(k);
    if (arr) arr.push(p);
    else map.set(k, [p]);
  }
  return [...map.values()].map((g) => (g.length > 1 ? [...g].sort((a, b) => colorRank(a.color) - colorRank(b.color)) : g));
}

const hasPrice = (p: ProductJSON) => availableModes(p as ProductPricing).length > 0;

function readCart(): CartLine[] {
  try {
    const raw = localStorage.getItem(CART_KEY);
    return raw ? (JSON.parse(raw) as CartLine[]) : [];
  } catch {
    return [];
  }
}

export interface CategoryInfo {
  name: string;
  count: number;
}

const CAT_ICON: Record<string, IconName> = { Aluminio: "box", Vidrio: "sparkles", Espejos: "sparkles", Tornillería: "tag", Jaladeras: "tag" };

export default function Pos({ defaultPct, categories }: { defaultPct: number; categories: CategoryInfo[] }) {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("");
  const [results, setResults] = useState<ProductJSON[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchError, setSearchError] = useState("");

  const [cart, setCart] = useState<CartLine[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [dialogVariants, setDialogVariants] = useState<ProductJSON[] | null>(null);
  const [customerType, setCustomerType] = useState<CustomerType>("particular");
  const [editing, setEditing] = useState<CartLine | null>(null);

  const [method, setMethod] = useState<PaymentMethod | null>(null);
  const [pct, setPct] = useState(String(defaultPct));
  const [cash, setCash] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState<"" | "venta" | "cotizacion">("");
  const [error, setError] = useState("");
  const [tab, setTab] = useState<"productos" | "carrito">("productos");
  const searchRef = useRef<HTMLInputElement>(null);

  // Carrito guardado en este navegador por si se recarga la página.
  useEffect(() => {
    setCart(readCart());
    setHydrated(true);
  }, []);
  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(CART_KEY, JSON.stringify(cart));
    } catch {
      /* sin almacenamiento disponible */
    }
  }, [cart, hydrated]);

  // Sin búsqueda ni categoría se muestran las categorías (navegación de un toque).
  const browsing = !q.trim() && !category;

  // Búsqueda con pequeño retraso mientras se escribe.
  useEffect(() => {
    if (!q.trim() && !category) {
      setResults([]);
      setLoading(false);
      return;
    }
    const ctrl = new AbortController();
    const t = setTimeout(async () => {
      setLoading(true);
      setSearchError("");
      try {
        const params = new URLSearchParams({ q, category });
        const res = await fetch(`/api/products?${params}`, { signal: ctrl.signal });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        setResults(data.products);
      } catch (e) {
        if ((e as Error).name !== "AbortError") setSearchError((e as Error).message || "No se pudo buscar");
      } finally {
        setLoading(false);
      }
    }, 200);
    return () => {
      clearTimeout(t);
      ctrl.abort();
    };
  }, [q, category]);

  const groups = useMemo(() => groupProducts(results), [results]);

  // Al cambiar el tipo de cliente se recalculan los renglones (afecta el m² del vidrio).
  function changeCustomerType(t: CustomerType) {
    setCustomerType(t);
    setCart((c) =>
      c.map((l) => {
        try {
          return { ...l, priced: priceLine(l.product as ProductPricing, l.input, { customerType: t }) };
        } catch {
          return l;
        }
      }),
    );
  }

  /** Variantes del grupo de un producto (para editar un renglón con su selector de color). */
  function variantsOf(p: ProductJSON): ProductJSON[] {
    if (!p.group) return [p];
    const g = groups.find((arr) => arr.some((x) => x._id === p._id));
    return g ?? [p];
  }

  const pctNum = Number(pct.replace(",", "."));
  const totals = useMemo(() => {
    try {
      return computeTotals(cart.map((l) => l.priced), method, method === "terminal" ? pctNum : 0);
    } catch {
      return null;
    }
  }, [cart, method, pctNum]);
  const cashNum = Number(cash.replace(",", "."));
  const changeDue = method === "efectivo" && cash !== "" && totals ? round2(cashNum - totals.total) : null;

  const confirmLine = useCallback((line: CartLine) => {
    setCart((c) => (c.some((x) => x.key === line.key) ? c.map((x) => (x.key === line.key ? line : x)) : [...c, line]));
    setDialogVariants(null);
    setEditing(null);
    searchRef.current?.focus();
  }, []);

  function resetSale() {
    setCart([]);
    setMethod(null);
    setCustomerType("particular");
    setPct(String(defaultPct));
    setCash("");
    setCustomerName("");
    setCustomerPhone("");
    setNotes("");
  }

  async function save(kind: "venta" | "cotizacion") {
    setError("");
    if (!cart.length) return setError("Agrega al menos un producto.");
    if (kind === "venta" && !method) return setError("Elige el método de pago.");
    if (method === "terminal" && (!Number.isFinite(pctNum) || pctNum < 0 || pctNum > MAX_COMMISSION_PCT)) {
      return setError(`La comisión debe estar entre 0% y ${MAX_COMMISSION_PCT}%.`);
    }
    if (kind === "venta" && method === "efectivo" && cash !== "" && changeDue !== null && changeDue < 0) {
      return setError("El efectivo recibido es menor al total.");
    }
    setSaving(kind);
    try {
      const res = await fetch("/api/sales", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          kind,
          items: cart.map((l) => ({ productId: l.product._id, ...l.input })),
          paymentMethod: method,
          customerType,
          commissionPct: method === "terminal" ? pctNum : 0,
          cashReceived: method === "efectivo" && cash !== "" ? cashNum : null,
          customerName,
          customerPhone,
          notes,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "No se pudo guardar");
      resetSale();
      router.push(`/notas/${data.id}?nuevo=1`);
    } catch (e) {
      setError((e as Error).message);
      setSaving("");
    }
  }

  const count = cart.length;

  return (
    <div className="mx-auto flex max-w-[1500px] flex-col gap-4 lg:grid lg:grid-cols-[minmax(0,1fr)_400px] lg:items-start lg:gap-5">

      <div className="flex items-end justify-between gap-3 lg:col-span-2">
        <div>
          <h1 className="font-display text-3xl font-medium sm:text-4xl">Mostrador</h1>
          <p className="mt-1 hidden text-muted sm:block">Busca o elige una categoría, toca el producto y captura la medida.</p>
        </div>
      </div>

      {/* Pestañas en celular */}
      <div role="tablist" aria-label="Vista" className="grid grid-cols-2 gap-1 rounded-full bg-surface p-1 shadow-[var(--surface-shadow)] lg:hidden">
        {(["productos", "carrito"] as const).map((t) => (
          <button
            key={t}
            role="tab"
            aria-selected={tab === t}
            onClick={() => setTab(t)}
            className={cx("min-h-11 rounded-full font-semibold transition-colors", tab === t ? "bg-accent text-accent-foreground" : "text-muted hover:bg-default")}
          >
            {t === "productos" ? "Productos" : `Venta (${count})`}
          </button>
        ))}
      </div>

      {/* Buscador y resultados */}
      <section aria-label="Productos" className={cx("flex min-w-0 flex-col gap-4", tab !== "productos" && "hidden lg:flex", count > 0 && "pb-20 lg:pb-0")}>
        <SearchField aria-label="Buscar producto" value={q} onChange={setQ} className="w-full">
          <SearchField.Group className="h-14 rounded-2xl bg-surface shadow-[var(--surface-shadow)]">
            <SearchField.SearchIcon className="ml-1 size-5" />
            <SearchField.Input ref={searchRef} placeholder="Buscar: cabezal 2, claro 6, bisagra…" className="text-base" autoComplete="off" />
            <SearchField.ClearButton />
          </SearchField.Group>
        </SearchField>

        <div role="group" aria-label="Categorías" className="no-scrollbar -mx-3 flex gap-2 overflow-x-auto px-3 sm:mx-0 sm:px-0">
          {[{ name: "", count: 0 }, ...categories].map((c) => {
            const active = category === c.name;
            return (
              <button
                key={c.name || "_all"}
                type="button"
                aria-pressed={active}
                onClick={() => setCategory(c.name)}
                className={cx(
                  "min-h-10 shrink-0 rounded-full px-4 text-sm font-semibold transition-colors outline-none focus-visible:ring-2 focus-visible:ring-focus",
                  active ? "bg-accent text-accent-foreground" : "bg-surface text-foreground shadow-[var(--surface-shadow)] hover:bg-surface-secondary",
                )}
              >
                {c.name || "Todas"}
              </button>
            );
          })}
        </div>

        {browsing && (
          <ul aria-label="Elige una categoría" className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
            {categories.map((c) => (
              <li key={c.name}>
                <button
                  type="button"
                  onClick={() => setCategory(c.name)}
                  className="flex h-full min-h-24 w-full flex-col items-start justify-between gap-3 rounded-2xl bg-surface p-4 text-left shadow-[var(--surface-shadow)] outline-none transition hover:-translate-y-0.5 hover:shadow-[var(--overlay-shadow)] focus-visible:ring-2 focus-visible:ring-focus"
                >
                  <span className="flex size-10 items-center justify-center rounded-xl bg-accent-soft text-accent-soft-foreground">
                    <Icon name={CAT_ICON[c.name] ?? "tag"} />
                  </span>
                  <span>
                    <span className="block font-semibold leading-tight">{c.name}</span>
                    <span className="text-sm text-muted">{c.count} producto(s)</span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        )}

        {searchError && <Alert>{searchError}</Alert>}
        {!browsing && (
          <p className="text-sm text-muted" aria-live="polite">
            {loading ? "Buscando…" : `${groups.length} producto(s)${results.length >= 150 ? " — afina la búsqueda para ver más" : ""}`}
          </p>
        )}

        <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2 2xl:grid-cols-3">
          {groups.map((g) => {
            const first = g.find(hasPrice) ?? g[0];
            const multi = g.length > 1;
            const anyPrice = g.some(hasPrice);
            return (
              <li key={first._id}>
                <button
                  onClick={() => {
                    setEditing(null);
                    setDialogVariants(g);
                  }}
                  className={cx(
                    "flex h-full min-h-11 w-full flex-col gap-1 rounded-2xl bg-surface p-4 text-left shadow-[var(--surface-shadow)] outline-none transition hover:-translate-y-0.5 hover:shadow-[var(--overlay-shadow)] focus-visible:ring-2 focus-visible:ring-focus active:scale-[0.99]",
                    !anyPrice && "opacity-70",
                  )}
                >
                  <span className="text-sm text-muted">
                    {multi ? first.category : `${first.code} · ${first.category}`}
                    {first.line ? ` · ${first.line}` : ""}
                  </span>
                  <span className="font-semibold leading-snug">{multi ? first.group : first.name}</span>
                  {multi ? (
                    <span className="text-sm text-muted">
                      {g.length} acabados: {g.map((v) => v.color || v.name).join(", ")}
                    </span>
                  ) : (
                    first.color && <span className="text-sm text-muted">{first.color}</span>
                  )}
                  <span className="mt-auto pt-1 text-sm font-medium tabular">
                    {anyPrice ? (
                      <>
                        {multi && <span className="block text-muted">{first.color}:</span>}
                        {priceSummary(first).map((s) => (
                          <span key={s} className="block">
                            {s}
                          </span>
                        ))}
                      </>
                    ) : (
                      <span className="block text-warn">Sin precio</span>
                    )}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </section>

      {/* Carrito y cobro */}
      <section
        aria-label="Carrito"
        className={cx(
          "flex min-w-0 flex-col gap-4 rounded-3xl bg-surface p-4 shadow-[var(--surface-shadow)] lg:p-5 lg:sticky lg:top-3 lg:max-h-[calc(100dvh-1.5rem)] lg:overflow-y-auto",
          tab !== "carrito" && "hidden lg:flex",
        )}
      >
        <div className="flex items-center justify-between gap-2">
          <h2 className="font-display text-2xl">Venta actual</h2>
          {count > 0 && (
            <button onClick={() => setCart([])} className="min-h-10 rounded-full px-4 text-sm font-medium text-danger hover:bg-danger-soft">
              Vaciar
            </button>
          )}
        </div>

        {count === 0 ? (
          <div className="flex flex-col items-center gap-2 rounded-2xl bg-surface-secondary p-6 text-center">
            <span className="flex size-12 items-center justify-center rounded-full bg-surface text-muted">
              <Icon name="cart" />
            </span>
            <p className="font-medium">Aún no hay productos</p>
            <p className="text-sm text-muted">Toca un producto de la lista para agregarlo.</p>
          </div>
        ) : (
          <ul className="flex flex-col divide-y divide-separator">
            {cart.map((l) => (
              <li key={l.key} className="flex items-start gap-2 py-3">
                <div className="min-w-0 flex-1">
                  <p className="font-semibold leading-snug">{l.product.name}</p>
                  <p className="text-sm text-muted">{l.priced.detail}</p>
                  <p className="text-sm tabular">
                    {formatNumber(l.priced.qty)} × {formatMoney(l.priced.unitPrice)}
                  </p>
                </div>
                <p className="pt-0.5 font-semibold tabular">{formatMoney(l.priced.subtotal)}</p>
                <div className="flex flex-col">
                  <button
                    aria-label={`Editar ${l.product.name}`}
                    onClick={() => {
                      setEditing(l);
                      setDialogVariants(variantsOf(l.product));
                    }}
                    className="flex size-10 items-center justify-center rounded-full text-muted hover:bg-default hover:text-foreground"
                  >
                    <Icon name="edit" />
                  </button>
                  <button
                    aria-label={`Quitar ${l.product.name}`}
                    onClick={() => setCart((c) => c.filter((x) => x.key !== l.key))}
                    className="flex size-10 items-center justify-center rounded-full text-danger hover:bg-danger-soft"
                  >
                    <Icon name="trash" />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}

        <details className="group rounded-2xl bg-surface-secondary">
          <summary className="flex min-h-12 cursor-pointer list-none items-center justify-between rounded-2xl px-4 font-medium outline-none focus-visible:ring-2 focus-visible:ring-focus">
            Datos del cliente <span className="text-sm text-muted group-open:hidden">Opcional</span>
          </summary>
          <div className="flex flex-col gap-3 px-4 pb-4">
            <Field label="Nombre" htmlFor="c-name">
              <Input id="c-name" value={customerName} onChange={(e) => setCustomerName(e.target.value)} autoComplete="off" />
            </Field>
            <Field label="Teléfono" htmlFor="c-phone">
              <Input id="c-phone" type="tel" value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} autoComplete="off" />
            </Field>
            <Field label="Notas" htmlFor="c-notes">
              <Input id="c-notes" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="ej. entrega a domicilio" />
            </Field>
          </div>
        </details>

        <fieldset>
          <legend className="mb-2 text-sm font-semibold text-muted">Tipo de cliente</legend>
          <div className="grid grid-cols-2 gap-1 rounded-2xl bg-default p-1">
            {CUSTOMER_TYPES.map((t) => (
              <label
                key={t}
                className={cx(
                  "flex min-h-11 cursor-pointer items-center justify-center rounded-xl px-1 text-center text-[15px] font-semibold transition-colors has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-focus",
                  customerType === t ? "bg-surface text-foreground shadow-sm" : "text-muted hover:text-foreground",
                )}
              >
                <input type="radio" name="ctype" value={t} checked={customerType === t} onChange={() => changeCustomerType(t)} className="sr-only" />
                {CUSTOMER_LABELS[t]}
              </label>
            ))}
          </div>
          <p className="mt-1 text-sm text-muted">Cambia el precio por m² del vidrio.</p>
        </fieldset>

        <fieldset>
          <legend className="mb-2 text-sm font-semibold text-muted">Método de pago</legend>
          <div className="grid grid-cols-3 gap-2">
            {PAYMENT_METHODS.map((m) => (
              <label
                key={m}
                className={cx(
                  "flex min-h-16 cursor-pointer flex-col items-center justify-center gap-1 rounded-2xl border px-1 text-center text-sm font-semibold transition-colors has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-focus",
                  method === m ? "border-accent bg-accent text-accent-foreground" : "border-border hover:bg-surface-secondary",
                )}
              >
                <input type="radio" name="method" value={m} checked={method === m} onChange={() => setMethod(m)} className="sr-only" />
                <Icon name={m === "efectivo" ? "wallet" : m === "terminal" ? "card" : "cash"} className="size-5" />
                {m === "terminal" ? "Terminal" : PAYMENT_LABELS[m]}
              </label>
            ))}
          </div>
        </fieldset>

        {method === "terminal" && (
          <div className="rounded-2xl bg-warning-soft p-4 text-warning-soft-foreground">
            <Field label="Comisión por terminal (%)" htmlFor="pct">
              <Input id="pct" inputMode="decimal" value={pct} onChange={(e) => setPct(e.target.value)} className="text-lg font-semibold" />
            </Field>
            <p className="mt-2 text-sm">Avísale al cliente que el pago con tarjeta lleva esta comisión sobre el total.</p>
          </div>
        )}

        {method === "efectivo" && (
          <Field label="Efectivo recibido (opcional)" htmlFor="cash">
            <Input id="cash" inputMode="decimal" value={cash} onChange={(e) => setCash(e.target.value)} placeholder="0.00" />
          </Field>
        )}

        <div className="flex flex-col gap-3 max-lg:sticky max-lg:bottom-[calc(4rem+env(safe-area-inset-bottom))] max-lg:-mx-4 max-lg:-mb-4 max-lg:rounded-b-3xl max-lg:bg-surface max-lg:px-4 max-lg:pb-4 max-lg:shadow-[0_-8px_16px_-12px_rgb(0_0_0/0.15)]">
        <dl className="flex flex-col gap-1.5 border-t border-dashed border-separator pt-4 tabular" aria-live="polite">
          <div className="flex justify-between text-muted">
            <dt>Subtotal</dt>
            <dd>{formatMoney(totals?.subtotal ?? 0)}</dd>
          </div>
          {method === "terminal" && (
            <div className="flex justify-between">
              <dt>Comisión terminal ({totals ? formatNumber(totals.commissionPct, 2) : "—"}%)</dt>
              <dd>{totals ? formatMoney(totals.commissionAmount) : "—"}</dd>
            </div>
          )}
          <div className="flex items-baseline justify-between pt-1">
            <dt className="text-lg font-semibold">Total</dt>
            <dd className="font-display text-3xl">{totals ? formatMoney(totals.total) : "—"}</dd>
          </div>
          {changeDue !== null && Number.isFinite(changeDue) && (
            <div className={cx("flex justify-between font-semibold", changeDue < 0 ? "text-bad" : "text-ok")}>
              <dt>{changeDue < 0 ? "Falta" : "Cambio"}</dt>
              <dd>{formatMoney(Math.abs(changeDue))}</dd>
            </div>
          )}
        </dl>

        {error && <Alert>{error}</Alert>}

        <div className="flex flex-col-reverse gap-2 sm:flex-row">
          <Button variant="secondary" onClick={() => save("cotizacion")} disabled={!!saving || !count} className="flex-1">
            {saving === "cotizacion" ? "Guardando…" : "Guardar cotización"}
          </Button>
          <Button onClick={() => save("venta")} disabled={!!saving || !count} className="min-h-12 flex-1 text-base">
            {saving === "venta" ? "Cobrando…" : "Cobrar venta"}
          </Button>
        </div>
        </div>
      </section>

      {/* Barra inferior móvil con el total */}
      {tab === "productos" && count > 0 && (
        <div className="fixed inset-x-3 bottom-[calc(4.75rem+env(safe-area-inset-bottom))] z-20 lg:hidden">
          <Button onClick={() => setTab("carrito")} className="min-h-14 w-full justify-between px-6 text-base shadow-[var(--overlay-shadow)]">
            <span>Ver venta ({count})</span>
            <span className="tabular">{formatMoney(totals?.total ?? 0)}</span>
          </Button>
        </div>
      )}

      <AddItemDialog
        variants={dialogVariants}
        initial={editing}
        customerType={customerType}
        onClose={() => {
          setDialogVariants(null);
          setEditing(null);
        }}
        onConfirm={confirmLine}
      />
    </div>
  );
}
