"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Chip, Table } from "@heroui/react";
import { formatMoney, PAYMENT_LABELS, type PaymentMethod } from "@/lib/pricing";
import { fmtDate, STATUS_LABEL } from "@/lib/labels";
import Icon from "./Icon";

export interface SaleRow {
  _id: string;
  folio: string;
  kind: "venta" | "cotizacion";
  status: string;
  createdAt: string;
  customerName?: string;
  sellerName?: string;
  paymentMethod?: PaymentMethod | null;
  commissionAmount: number;
  total: number;
  items: unknown[];
  validUntil?: string;
}

const PAY_ICON = { efectivo: "wallet", transferencia: "cash", terminal: "card" } as const;

function StatusChip({ r, now }: { r: SaleRow; now: number }) {
  const expired = r.kind === "cotizacion" && r.status === "vigente" && r.validUntil && new Date(r.validUntil).getTime() < now;
  if (expired) return <Chip size="sm" variant="soft" color="warning"><Chip.Label>Vencida</Chip.Label></Chip>;
  if (r.status === "cancelada") return <Chip size="sm" variant="soft" color="danger"><Chip.Label>Cancelada</Chip.Label></Chip>;
  if (r.status === "convertida") return <Chip size="sm" variant="soft" color="accent"><Chip.Label>Cobrada</Chip.Label></Chip>;
  return (
    <Chip size="sm" variant="soft" color="success">
      <Chip.Label>{r.kind === "venta" ? "Pagada" : STATUS_LABEL[r.status]}</Chip.Label>
    </Chip>
  );
}

function Payment({ r }: { r: SaleRow }) {
  if (!r.paymentMethod) return <span className="text-muted">—</span>;
  return (
    <span className="inline-flex items-center gap-1.5">
      <Icon name={PAY_ICON[r.paymentMethod]} className="size-4 text-muted" />
      {PAYMENT_LABELS[r.paymentMethod].replace(" (tarjeta)", "")}
      {r.commissionAmount > 0 && <span className="text-muted">+{formatMoney(r.commissionAmount)}</span>}
    </span>
  );
}

/** Lista de ventas/cotizaciones: tarjetas en celular, tabla HeroUI en pantallas medianas. */
export default function SalesTable({ rows, showSeller, quoteMode = false }: { rows: SaleRow[]; showSeller: boolean; quoteMode?: boolean }) {
  const router = useRouter();
  if (!rows.length) {
    return (
      <div className="flex flex-col items-center gap-2 rounded-3xl bg-surface p-10 text-center shadow-[var(--surface-shadow)]">
        <span className="flex size-12 items-center justify-center rounded-full bg-default text-muted">
          <Icon name={quoteMode ? "doc" : "cash"} />
        </span>
        <p className="font-medium">No hay registros con estos filtros</p>
        <p className="text-sm text-muted">Prueba con otro periodo o quita la búsqueda.</p>
      </div>
    );
  }
  const now = Date.now();
  const hrefOf = (r: SaleRow) => (quoteMode && r.status === "vigente" ? `/cotizaciones/${r._id}` : `/notas/${r._id}`);

  return (
    <>
      {/* Celular */}
      <ul className="flex flex-col gap-2 md:hidden">
        {rows.map((r) => (
          <li key={r._id}>
            <Link href={hrefOf(r)} className="flex flex-col gap-2 rounded-2xl bg-surface p-4 shadow-[var(--surface-shadow)] outline-none focus-visible:ring-2 focus-visible:ring-focus active:scale-[0.99]">
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold tabular">{r.folio}</span>
                <StatusChip r={r} now={now} />
              </div>
              <div className="flex items-end justify-between gap-3">
                <div className="min-w-0 text-sm text-muted">
                  <p className="truncate text-base text-foreground">{r.customerName || "Mostrador"}</p>
                  <p>
                    {fmtDate(r.createdAt)} · {r.items.length} renglón(es)
                  </p>
                  {showSeller && r.sellerName && <p>Atendió: {r.sellerName}</p>}
                  {!quoteMode && (
                    <p className="mt-0.5">
                      <Payment r={r} />
                    </p>
                  )}
                </div>
                <span className="font-display text-xl tabular">{formatMoney(r.total)}</span>
              </div>
            </Link>
          </li>
        ))}
      </ul>

      {/* Tablet / escritorio */}
      <Table className="hidden md:block">
        <Table.ScrollContainer>
          <Table.Content aria-label={quoteMode ? "Cotizaciones" : "Ventas"} onRowAction={(key) => router.push(String(key))}>
            <Table.Header>
              <Table.Column isRowHeader>Folio</Table.Column>
              <Table.Column>Fecha</Table.Column>
              <Table.Column>Cliente</Table.Column>
              {showSeller ? <Table.Column>Vendedor</Table.Column> : null}
              <Table.Column>{quoteMode ? "Vigencia" : "Pago"}</Table.Column>
              <Table.Column>Estado</Table.Column>
              <Table.Column className="text-right">Total</Table.Column>
            </Table.Header>
            <Table.Body>
              {rows.map((r) => (
                <Table.Row key={r._id} id={hrefOf(r)} className="cursor-pointer">
                  <Table.Cell className="font-semibold tabular">{r.folio}</Table.Cell>
                  <Table.Cell className="whitespace-nowrap text-muted">{fmtDate(r.createdAt)}</Table.Cell>
                  <Table.Cell>
                    {r.customerName || <span className="text-muted">Mostrador</span>}
                    <span className="block text-xs text-muted">{r.items.length} renglón(es)</span>
                  </Table.Cell>
                  {showSeller ? <Table.Cell>{r.sellerName}</Table.Cell> : null}
                  <Table.Cell className="whitespace-nowrap">{quoteMode ? <span className="text-muted">Hasta {fmtDate(r.validUntil, false)}</span> : <Payment r={r} />}</Table.Cell>
                  <Table.Cell>
                    <StatusChip r={r} now={now} />
                  </Table.Cell>
                  <Table.Cell className="text-right font-semibold tabular">{formatMoney(r.total)}</Table.Cell>
                </Table.Row>
              ))}
            </Table.Body>
          </Table.Content>
        </Table.ScrollContainer>
      </Table>
    </>
  );
}
