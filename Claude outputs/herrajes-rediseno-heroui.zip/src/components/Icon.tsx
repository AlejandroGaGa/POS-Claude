import {
  ArrowDownRight,
  ArrowRightFromSquare,
  ArrowUpRight,
  Bars,
  Box,
  Calendar,
  ChartColumn,
  ChevronLeft,
  CircleCheck,
  Clock,
  CreditCard,
  FileText,
  Gear,
  Magnifier,
  Minus,
  Pencil,
  Persons,
  Plus,
  Printer,
  Receipt,
  ShoppingCart,
  Sparkles,
  Tag,
  TrashBin,
  TriangleExclamation,
  Wallet,
  Xmark,
} from "@gravity-ui/icons";
import type { ComponentType, SVGProps } from "react";

// Íconos de Gravity UI (los mismos que usa la documentación de HeroUI).
const icons = {
  chart: ChartColumn,
  cart: ShoppingCart,
  doc: FileText,
  cash: Receipt,
  box: Box,
  users: Persons,
  gear: Gear,
  logout: ArrowRightFromSquare,
  menu: Bars,
  close: Xmark,
  plus: Plus,
  minus: Minus,
  trash: TrashBin,
  search: Magnifier,
  print: Printer,
  edit: Pencil,
  back: ChevronLeft,
  calendar: Calendar,
  sparkles: Sparkles,
  card: CreditCard,
  wallet: Wallet,
  clock: Clock,
  alert: TriangleExclamation,
  check: CircleCheck,
  up: ArrowUpRight,
  down: ArrowDownRight,
  tag: Tag,
} satisfies Record<string, ComponentType<SVGProps<SVGSVGElement>>>;

export type IconName = keyof typeof icons;

export default function Icon({ name, className = "size-5" }: { name: IconName; className?: string }) {
  const C = icons[name];
  return <C className={className} aria-hidden focusable={false} />;
}
