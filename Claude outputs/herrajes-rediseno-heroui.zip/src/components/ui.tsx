import type { ButtonHTMLAttributes, ComponentProps, ReactNode } from "react";

/**
 * Primitivas ligeras con el mismo lenguaje visual que HeroUI (botones tipo píldora,
 * campos redondeados, tarjetas blancas sobre fondo cálido). Se usan en formularios
 * nativos; los componentes interactivos complejos usan HeroUI directamente.
 */

export function cx(...c: (string | false | null | undefined)[]) {
  return c.filter(Boolean).join(" ");
}

type Variant = "primary" | "secondary" | "danger" | "ghost";
const variants: Record<Variant, string> = {
  primary: "bg-accent text-accent-foreground hover:bg-accent-hover shadow-sm",
  secondary: "bg-surface text-foreground border border-border hover:bg-surface-secondary",
  danger: "bg-danger text-danger-foreground hover:bg-danger-hover",
  ghost: "bg-transparent text-foreground hover:bg-default",
};

export function btn(variant: Variant = "primary", extra = "") {
  return cx(
    "inline-flex items-center justify-center gap-2 rounded-full px-5 min-h-11 text-[15px] font-semibold transition-colors outline-none focus-visible:ring-2 focus-visible:ring-focus focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap",
    variants[variant],
    extra,
  );
}

export function Button({ variant = "primary", className, ...props }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return <button {...props} className={btn(variant, className)} />;
}

export const inputCls =
  "w-full min-h-11 rounded-xl border border-field-border bg-field px-3.5 text-base text-field-foreground placeholder:text-field-placeholder outline-none transition-colors hover:border-field-border-hover focus:border-accent focus-visible:ring-2 focus-visible:ring-focus/30";

export function Input(props: ComponentProps<"input">) {
  return <input {...props} className={cx(inputCls, props.className)} />;
}

export function Select(props: ComponentProps<"select">) {
  return <select {...props} className={cx(inputCls, "pr-8", props.className)} />;
}

export function Textarea(props: ComponentProps<"textarea">) {
  return <textarea {...props} className={cx(inputCls, "py-2.5 min-h-20", props.className)} />;
}

export function Field({ label, htmlFor, hint, children, className }: { label: string; htmlFor: string; hint?: string; children: ReactNode; className?: string }) {
  return (
    <div className={cx("flex min-w-0 flex-col gap-1.5", className)}>
      <label htmlFor={htmlFor} className="text-sm font-medium text-foreground">
        {label}
      </label>
      {children}
      {hint && <p className="text-sm text-muted">{hint}</p>}
    </div>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <section className={cx("rounded-3xl bg-surface p-4 shadow-[var(--surface-shadow)] sm:p-6", className)}>{children}</section>;
}

/** Título de sección dentro de una tarjeta (serif, como la referencia). */
export function CardTitle({ children, className, as: Tag = "h2" }: { children: ReactNode; className?: string; as?: "h2" | "h3" }) {
  return <Tag className={cx("font-display text-xl font-medium text-foreground sm:text-2xl", className)}>{children}</Tag>;
}

type Tone = "neutral" | "accent" | "ok" | "warn" | "bad";
const tones: Record<Tone, string> = {
  neutral: "bg-default text-default-foreground",
  accent: "bg-accent-soft text-accent-soft-foreground",
  ok: "bg-success-soft text-success-soft-foreground",
  warn: "bg-warning-soft text-warning-soft-foreground",
  bad: "bg-danger-soft text-danger-soft-foreground",
};
export function Badge({ tone = "neutral", children }: { tone?: Tone; children: ReactNode }) {
  return <span className={cx("inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-sm font-medium whitespace-nowrap", tones[tone])}>{children}</span>;
}

export function Alert({ tone = "bad", children }: { tone?: "bad" | "ok" | "warn"; children: ReactNode }) {
  const icon = tone === "bad" ? "!" : tone === "ok" ? "✓" : "!";
  return (
    <div role={tone === "bad" ? "alert" : "status"} className={cx("flex items-start gap-3 rounded-2xl px-4 py-3 text-[15px]", tones[tone])}>
      <span aria-hidden className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-current/15 text-xs font-bold">
        {icon}
      </span>
      <div className="min-w-0">{children}</div>
    </div>
  );
}

/** Encabezado de página: el título grande vive en la barra superior; aquí van las acciones. */
export function PageHeader({ title, subtitle, children }: { title: string; subtitle?: string; children?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div className="min-w-0">
        <h1 className="font-display text-2xl font-medium sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1 text-muted">{subtitle}</p>}
      </div>
      {children && <div className="flex flex-wrap gap-2">{children}</div>}
    </div>
  );
}

/** Tarjeta de indicador (KPI) con cifra serif grande. */
export function Stat({ label, value, hint, className, emphasis }: { label: string; value: string; hint?: ReactNode; className?: string; emphasis?: boolean }) {
  return (
    <div className={cx("rounded-3xl bg-surface p-4 shadow-[var(--surface-shadow)] sm:p-5", className)}>
      <p className="text-sm text-muted">{label}</p>
      <p className={cx("font-display mt-2 tabular leading-none", emphasis ? "text-3xl sm:text-4xl" : "text-2xl sm:text-3xl")}>{value}</p>
      {hint && <div className="mt-2 text-sm text-muted">{hint}</div>}
    </div>
  );
}
