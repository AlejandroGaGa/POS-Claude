"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { ROLE_DESCRIPTIONS, ROLE_LABELS, ROLES, type Role } from "@/lib/roles";
import { Alert, Badge, Button, Card, Field, Input, Select } from "./ui";

export interface UserRow {
  _id: string;
  name: string;
  username: string;
  role: Role;
  active: boolean;
}

async function call(url: string, method: string, body: unknown) {
  const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Error");
  return data;
}

export default function UsersManager({ users, meId }: { users: UserRow[]; meId: string }) {
  const router = useRouter();
  const [msg, setMsg] = useState<{ tone: "ok" | "bad"; text: string } | null>(null);

  async function create(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const f = new FormData(form);
    try {
      await call("/api/users", "POST", { name: f.get("name"), username: f.get("username"), password: f.get("password"), role: f.get("role") });
      form.reset();
      setMsg({ tone: "ok", text: "Usuario creado." });
      router.refresh();
    } catch (err) {
      setMsg({ tone: "bad", text: (err as Error).message });
    }
  }

  async function update(id: string, body: Record<string, unknown>, okText: string) {
    try {
      await call(`/api/users/${id}`, "PUT", body);
      setMsg({ tone: "ok", text: okText });
      router.refresh();
    } catch (err) {
      setMsg({ tone: "bad", text: (err as Error).message });
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <Card>
        <h2 className="font-display mb-2 text-xl font-medium">Roles</h2>
        <ul className="flex flex-col gap-1">
          {ROLES.map((r) => (
            <li key={r}>
              <strong>{ROLE_LABELS[r]}:</strong> {ROLE_DESCRIPTIONS[r]}
            </li>
          ))}
        </ul>
      </Card>

      {msg && <Alert tone={msg.tone}>{msg.text}</Alert>}

      <Card>
        <h2 className="font-display mb-3 text-xl font-medium">Nuevo usuario</h2>
        <form onSubmit={create} className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label="Nombre" htmlFor="n-name">
            <Input id="n-name" name="name" required />
          </Field>
          <Field label="Usuario (para entrar)" htmlFor="n-user" hint="Minúsculas, sin espacios">
            <Input id="n-user" name="username" required autoCapitalize="none" pattern="[a-zA-Z0-9._\-]{3,30}" />
          </Field>
          <Field label="Contraseña" htmlFor="n-pass" hint="Mínimo 6 caracteres">
            <Input id="n-pass" name="password" type="password" required minLength={6} autoComplete="new-password" />
          </Field>
          <Field label="Rol" htmlFor="n-role">
            <Select id="n-role" name="role" defaultValue="vendedor">
              {ROLES.map((r) => (
                <option key={r} value={r}>
                  {ROLE_LABELS[r]}
                </option>
              ))}
            </Select>
          </Field>
          <Button type="submit" className="sm:col-span-2 sm:w-fit">
            Crear usuario
          </Button>
        </form>
      </Card>

      <ul className="flex flex-col gap-3">
        {users.map((u) => (
          <li key={u._id}>
            <Card>
              <div className="flex flex-wrap items-center gap-2">
                <p className="text-lg font-semibold">{u.name}</p>
                <span className="text-muted">@{u.username}</span>
                {u._id === meId && <Badge tone="accent">Tú</Badge>}
                {!u.active && <Badge tone="bad">Inactivo</Badge>}
              </div>
              <div className="mt-3 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-end">
                <Field label="Rol" htmlFor={`role-${u._id}`} className="sm:w-60">
                  <Select id={`role-${u._id}`} defaultValue={u.role} onChange={(e) => update(u._id, { role: e.target.value }, `Rol de ${u.name} actualizado.`)}>
                    {ROLES.map((r) => (
                      <option key={r} value={r}>
                        {ROLE_LABELS[r]}
                      </option>
                    ))}
                  </Select>
                </Field>
                <form
                  className="flex items-end gap-2"
                  onSubmit={(e) => {
                    e.preventDefault();
                    const input = e.currentTarget.elements.namedItem("pw") as HTMLInputElement;
                    update(u._id, { password: input.value }, `Contraseña de ${u.name} cambiada.`);
                    input.value = "";
                  }}
                >
                  <Field label="Nueva contraseña" htmlFor={`pw-${u._id}`}>
                    <Input id={`pw-${u._id}`} name="pw" type="password" minLength={6} required autoComplete="new-password" />
                  </Field>
                  <Button type="submit" variant="secondary">
                    Cambiar
                  </Button>
                </form>
                {u._id !== meId && (
                  <Button variant="secondary" className={u.active ? "text-bad" : ""} onClick={() => update(u._id, { active: !u.active }, u.active ? `${u.name} desactivado.` : `${u.name} reactivado.`)}>
                    {u.active ? "Desactivar" : "Reactivar"}
                  </Button>
                )}
              </div>
            </Card>
          </li>
        ))}
      </ul>
    </div>
  );
}
