"use client";
import { useState } from "react";
import type { SettingsData } from "@/lib/models/Settings";
import { Alert, Button, Card, Field, Input, Textarea } from "./ui";

export default function SettingsForm({ settings }: { settings: SettingsData }) {
  const [msg, setMsg] = useState<{ tone: "ok" | "bad"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    const body = Object.fromEntries(new FormData(e.currentTarget));
    const res = await fetch("/api/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const data = await res.json();
    setBusy(false);
    setMsg(res.ok ? { tone: "ok", text: "Ajustes guardados." } : { tone: "bad", text: data.error });
  }

  return (
    <form onSubmit={submit} className="flex flex-col gap-4">
      <Card>
        <h2 className="font-display mb-3 text-xl font-medium">Datos que salen en la nota</h2>
        <div className="flex flex-col gap-3">
          <Field label="Nombre del negocio" htmlFor="businessName">
            <Input id="businessName" name="businessName" defaultValue={settings.businessName} required />
          </Field>
          <Field label="Dirección" htmlFor="address">
            <Input id="address" name="address" defaultValue={settings.address} />
          </Field>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <Field label="Teléfono" htmlFor="phone">
              <Input id="phone" name="phone" defaultValue={settings.phone} />
            </Field>
            <Field label="RFC" htmlFor="rfc">
              <Input id="rfc" name="rfc" defaultValue={settings.rfc} />
            </Field>
          </div>
          <Field label="Pie de la nota" htmlFor="ticketFooter">
            <Textarea id="ticketFooter" name="ticketFooter" defaultValue={settings.ticketFooter} />
          </Field>
        </div>
      </Card>
      <Card>
        <h2 className="font-display mb-3 text-xl font-medium">Ventas</h2>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label="Comisión de terminal sugerida (%)" htmlFor="defaultCommissionPct" hint="El vendedor la puede cambiar en cada venta">
            <Input id="defaultCommissionPct" name="defaultCommissionPct" inputMode="decimal" defaultValue={settings.defaultCommissionPct} required />
          </Field>
          <Field label="Vigencia de cotizaciones (días)" htmlFor="quoteValidityDays" hint="Después se recalcula con precios actuales">
            <Input id="quoteValidityDays" name="quoteValidityDays" inputMode="numeric" defaultValue={settings.quoteValidityDays} required />
          </Field>
        </div>
      </Card>
      {msg && <Alert tone={msg.tone}>{msg.text}</Alert>}
      <Button type="submit" disabled={busy} className="sm:w-fit">
        {busy ? "Guardando…" : "Guardar ajustes"}
      </Button>
    </form>
  );
}
