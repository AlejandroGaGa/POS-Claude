"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Avatar, Drawer, Kbd, SearchField } from "@heroui/react";
import { ROLE_LABELS } from "@/lib/roles";
import type { SessionUser } from "@/lib/session";
import { btn, cx } from "./ui";
import Icon, { type IconName } from "./Icon";

export interface NavItem {
  href: string;
  label: string;
  /** Etiqueta corta para la barra inferior en celular. */
  short: string;
  icon: IconName;
  section: "General" | "Gestión" | "Otros";
  /** Aparece en la barra inferior del celular. */
  primary?: boolean;
}

function initials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]!.toUpperCase())
    .join("");
}

function Logo() {
  return (
    <Link href="/" className="flex items-center gap-2.5 rounded-2xl outline-none focus-visible:ring-2 focus-visible:ring-focus">
      <span className="flex h-10 w-12 items-center justify-center rounded-2xl bg-foreground text-background">
        <svg viewBox="0 0 24 24" className="size-5" aria-hidden fill="currentColor">
          <path d="M5 21V3h3.2v7.3h7.6V3H19v18h-3.2v-7.6H8.2V21z" />
        </svg>
      </span>
      <span className="text-lg font-semibold tracking-tight">Herrajes POS</span>
    </Link>
  );
}

/** Buscador global: lleva a la lista de precios filtrada. ⌘K / Ctrl+K lo enfoca. */
function GlobalSearch({ onDone }: { onDone?: () => void }) {
  const router = useRouter();
  const ref = useRef<HTMLInputElement>(null);
  const [q, setQ] = useState("");
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        ref.current?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
  return (
    <SearchField
      variant="secondary"
      aria-label="Buscar producto"
      value={q}
      onChange={setQ}
      onSubmit={(v) => {
        if (!v.trim()) return;
        router.push(`/productos?q=${encodeURIComponent(v.trim())}`);
        setQ("");
        onDone?.();
      }}
      className="w-full"
    >
      <SearchField.Group className="h-11 rounded-xl">
        <SearchField.SearchIcon />
        <SearchField.Input ref={ref} placeholder="Buscar precio…" />
        <SearchField.ClearButton />
        <Kbd className="mr-2 hidden lg:inline-flex" aria-hidden>
          <Kbd.Abbr keyValue="command" />
          <Kbd.Content>K</Kbd.Content>
        </Kbd>
      </SearchField.Group>
    </SearchField>
  );
}

function NavList({ nav, pathname, onNavigate }: { nav: NavItem[]; pathname: string; onNavigate?: () => void }) {
  const sections = ["General", "Gestión", "Otros"] as const;
  return (
    <nav aria-label="Principal" className="flex flex-col gap-5">
      {sections.map((s) => {
        const items = nav.filter((n) => n.section === s);
        if (!items.length) return null;
        return (
          <div key={s}>
            <p className="mb-1.5 px-3 text-xs font-semibold tracking-wider text-muted uppercase">{s}</p>
            <ul className="flex flex-col gap-0.5">
              {items.map((n) => {
                const active = pathname === n.href || pathname.startsWith(n.href + "/");
                return (
                  <li key={n.href}>
                    <Link
                      href={n.href}
                      onClick={onNavigate}
                      aria-current={active ? "page" : undefined}
                      className={cx(
                        "flex min-h-11 items-center gap-3 rounded-xl px-3 text-[15px] font-medium transition-colors outline-none focus-visible:ring-2 focus-visible:ring-focus",
                        active ? "bg-default text-foreground" : "text-muted hover:bg-default/60 hover:text-foreground",
                      )}
                    >
                      <Icon name={n.icon} className={cx("size-5", active && "text-accent")} />
                      {n.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        );
      })}
    </nav>
  );
}

function UserCard({ user, onLogout }: { user: SessionUser; onLogout: () => void }) {
  return (
    <div className="flex items-center gap-3 rounded-2xl bg-surface-secondary p-2.5">
      <Avatar size="sm" color="accent">
        <Avatar.Fallback>{initials(user.name)}</Avatar.Fallback>
      </Avatar>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold">{user.name}</p>
        <p className="truncate text-xs text-muted">{ROLE_LABELS[user.role]}</p>
      </div>
      <button
        onClick={onLogout}
        aria-label="Cerrar sesión"
        title="Cerrar sesión"
        className="flex size-10 items-center justify-center rounded-xl text-muted transition-colors hover:bg-default hover:text-foreground outline-none focus-visible:ring-2 focus-visible:ring-focus"
      >
        <Icon name="logout" />
      </button>
    </div>
  );
}

export default function Shell({ user, nav, children }: { user: SessionUser; nav: NavItem[]; children: React.ReactNode }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const bottom = nav.filter((n) => n.primary || n.href === "/tablero").slice(0, 5);
  const canSell = nav.some((n) => n.href === "/mostrador");

  useEffect(() => setOpen(false), [pathname]);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.href = "/login";
  }

  return (
    <div className="min-h-[100dvh] lg:flex lg:gap-2 lg:p-3">
      {/* Sidebar de escritorio */}
      <aside className="no-print sticky top-3 hidden h-[calc(100dvh-1.5rem)] w-[272px] shrink-0 flex-col gap-6 rounded-3xl bg-surface p-4 shadow-[var(--surface-shadow)] lg:flex">
        <Logo />
        <GlobalSearch />
        <div className="min-h-0 flex-1 overflow-y-auto">
          <NavList nav={nav} pathname={pathname} />
        </div>
        <UserCard user={user} onLogout={logout} />
      </aside>

      {/* Barra superior en celular/tablet */}
      <header className="no-print sticky top-0 z-30 flex h-16 items-center gap-2 border-b border-separator bg-background/85 px-3 backdrop-blur-md lg:hidden">
        <button
          onClick={() => setOpen(true)}
          aria-label="Abrir menú"
          className="flex size-11 items-center justify-center rounded-xl hover:bg-default outline-none focus-visible:ring-2 focus-visible:ring-focus"
        >
          <Icon name="menu" />
        </button>
        <Logo />
        {canSell && (
          <Link href="/mostrador" className={btn("primary", "ml-auto min-h-10 px-4 text-sm")}>
            <Icon name="plus" className="size-4" /> Venta
          </Link>
        )}
      </header>

      <Drawer.Backdrop isOpen={open} onOpenChange={setOpen}>
        <Drawer.Content placement="left">
          <Drawer.Dialog className="w-[300px] max-w-[85vw]" aria-label="Menú">
            <Drawer.CloseTrigger aria-label="Cerrar menú" />
            <Drawer.Header>
              <Drawer.Heading className="sr-only">Menú</Drawer.Heading>
              <Logo />
            </Drawer.Header>
            <Drawer.Body className="flex flex-col gap-5">
              <GlobalSearch onDone={() => setOpen(false)} />
              <NavList nav={nav} pathname={pathname} onNavigate={() => setOpen(false)} />
            </Drawer.Body>
            <Drawer.Footer className="block">
              <UserCard user={user} onLogout={logout} />
            </Drawer.Footer>
          </Drawer.Dialog>
        </Drawer.Content>
      </Drawer.Backdrop>

      <main className="min-w-0 flex-1 px-3 pt-4 pb-[calc(5.5rem+env(safe-area-inset-bottom))] sm:px-5 lg:px-5 lg:pt-4 lg:pb-6">{children}</main>

      {/* Barra inferior en celular: lo que más se usa en mostrador a un toque */}
      <nav
        aria-label="Accesos rápidos"
        className="no-print fixed inset-x-0 bottom-0 z-30 border-t border-separator bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md lg:hidden"
      >
        <ul className="mx-auto grid max-w-xl" style={{ gridTemplateColumns: `repeat(${bottom.length}, minmax(0, 1fr))` }}>
          {bottom.map((n) => {
            const active = pathname === n.href || pathname.startsWith(n.href + "/");
            return (
              <li key={n.href}>
                <Link
                  href={n.href}
                  aria-current={active ? "page" : undefined}
                  className={cx(
                    "flex h-16 flex-col items-center justify-center gap-1 text-xs font-medium outline-none focus-visible:bg-default",
                    active ? "text-accent" : "text-muted",
                  )}
                >
                  <span className={cx("flex h-7 w-12 items-center justify-center rounded-full transition-colors", active && "bg-accent-soft")}>
                    <Icon name={n.icon} className="size-5" />
                  </span>
                  {n.short}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
