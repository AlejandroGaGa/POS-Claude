"use client";
import { useState } from "react";
import { CSV_EXAMPLE, parseCsv, rowToProduct, type ImportRow } from "@/lib/csvImport";
import { formatMoney } from "@/lib/pricing";
import { Alert, Button, Card, Field, Textarea } from "./ui";

interface Preview {
  creates: number;
  updates: number;
  priceChanges?: number;
  errors: { line: number; error: string }[];
  sample?: { code: string; name: string; changes: { field: string; from: unknown; to: unknown }[] }[];
  apply: boolean;
}

const fmt = (v: unknown) => (typeof v === "number" ? formatMoney(v) : v === null || v === undefined ? "—" : Array.isArray(v) ? v.map((b) => `${b.lengthM}m ${formatMoney(b.price)}`).join(", ") : typeof v === "object" ? formatMoney((v as { price: number }).price) : String(v));

export default function ImportProducts() {
  const [text, setText] = useState("");
  const [rows, setRows] = useState<ImportRow[]>([]);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState("");

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (file) setText(await file.text());
  }

  async function send(apply: boolean, parsed = rows) {
    setBusy(true);
    setError("");
    const res = await fetch("/api/products/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rows: parsed.filter((r) => r.data).map((r) => ({ line: r.line, data: r.data })), apply }),
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) return setError(data.error);
    if (apply && data.apply) {
      setDone(`Listo: ${data.creates} producto(s) nuevos y ${data.updates} actualizados.`);
      setPreview(null);
      setRows([]);
      setText("");
    } else setPreview({ ...data, errors: [...parsed.filter((r) => r.error).map((r) => ({ line: r.line, error: r.error! })), ...data.errors] });
  }

  function analyze() {
    setDone("");
    const parsed = parseCsv(text).map((r, i) => rowToProduct(r, i + 2));
    if (!parsed.length) return setError("No encontré renglones. Revisa que la primera fila tenga los encabezados.");
    setRows(parsed);
    send(false, parsed);
  }

  return (
    <div className="flex flex-col gap-4">
      <Card>
        <h2 className="font-display mb-2 text-xl font-medium">1. Prepara tu archivo</h2>
        <p className="mb-2">
          Usa un CSV (en Excel: <em>Guardar como → CSV</em>) con estos encabezados. Lo más fácil: descarga la lista actual con «Descargar CSV», edítala en Excel y vuelve a subirla. Los productos se
          reconocen por <strong>código</strong>: si existe se actualiza, si no se crea.
        </p>
        <ul className="mb-3 list-disc pl-5 text-sm">
          <li>
            <strong>tipo</strong>: pieza, kg, metro, perfil o vidrio
          </li>
          <li>
            <strong>tiras</strong> (perfiles): <code>6:520|3.6:330|4.6:410</code> → largo en metros : precio
          </li>
          <li>
            <strong>hoja</strong> (vidrio): <code>1.80x2.60:2100</code> → base x altura en metros : precio
          </li>
        </ul>
        <details>
          <summary className="min-h-11 cursor-pointer py-2 font-semibold">Ver ejemplo</summary>
          <pre className="overflow-x-auto rounded-lg bg-surface-2 p-3 text-sm">{CSV_EXAMPLE}</pre>
          <Button type="button" variant="ghost" onClick={() => setText(CSV_EXAMPLE)}>
            Usar el ejemplo
          </Button>
        </details>
      </Card>

      <Card>
        <h2 className="font-display mb-2 text-xl font-medium">2. Sube o pega el contenido</h2>
        <div className="flex flex-col gap-3">
          <Field label="Archivo CSV" htmlFor="file">
            <input id="file" type="file" accept=".csv,text/csv,text/plain" onChange={onFile} className="min-h-11 text-base file:mr-3 file:min-h-11 file:rounded-lg file:border file:border-line file:bg-surface-2 file:px-4 file:font-semibold file:text-ink" />
          </Field>
          <Field label="…o pega aquí" htmlFor="csv">
            <Textarea id="csv" value={text} onChange={(e) => setText(e.target.value)} rows={8} className="font-mono text-sm" />
          </Field>
          <Button onClick={analyze} disabled={!text.trim() || busy}>
            {busy && !preview ? "Revisando…" : "Revisar antes de importar"}
          </Button>
        </div>
      </Card>

      {error && <Alert>{error}</Alert>}
      {done && <Alert tone="ok">{done}</Alert>}

      {preview && (
        <Card>
          <h2 className="font-display mb-2 text-xl font-medium">3. Confirma</h2>
          <p>
            <strong>{preview.creates}</strong> nuevos · <strong>{preview.updates}</strong> existentes ({preview.priceChanges ?? 0} con cambio de precio)
          </p>
          {preview.errors.length > 0 && (
            <div className="my-3">
              <Alert>
                <p className="font-semibold">Corrige estos renglones antes de importar:</p>
                <ul className="list-disc pl-5">
                  {preview.errors.slice(0, 30).map((e, i) => (
                    <li key={i}>{e.line ? `Renglón ${e.line}: ${e.error}` : e.error}</li>
                  ))}
                </ul>
              </Alert>
            </div>
          )}
          {!!preview.sample?.length && (
            <div className="my-3 overflow-x-auto">
              <table className="w-full text-sm">
                <caption className="mb-1 text-left font-semibold">Cambios de precio (muestra)</caption>
                <thead>
                  <tr className="border-b border-line text-left">
                    <th className="py-1 pr-2">Producto</th>
                    <th className="py-1 pr-2">Campo</th>
                    <th className="py-1 pr-2">Antes</th>
                    <th className="py-1">Después</th>
                  </tr>
                </thead>
                <tbody>
                  {preview.sample.flatMap((s) =>
                    s.changes.map((c, i) => (
                      <tr key={s.code + i} className="border-b border-line">
                        <td className="py-1 pr-2">{i === 0 ? `${s.code} ${s.name}` : ""}</td>
                        <td className="py-1 pr-2">{c.field}</td>
                        <td className="py-1 pr-2 tabular">{fmt(c.from)}</td>
                        <td className="py-1 tabular">{fmt(c.to)}</td>
                      </tr>
                    )),
                  )}
                </tbody>
              </table>
            </div>
          )}
          <Button onClick={() => send(true)} disabled={busy || preview.errors.length > 0 || preview.creates + preview.updates === 0}>
            {busy ? "Importando…" : `Importar ${preview.creates + preview.updates} producto(s)`}
          </Button>
        </Card>
      )}
    </div>
  );
}
