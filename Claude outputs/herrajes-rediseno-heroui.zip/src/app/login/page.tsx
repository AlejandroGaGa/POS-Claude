import { redirect } from "next/navigation";
import { Suspense } from "react";
import { getSession } from "@/lib/auth";
import { homeFor } from "@/lib/roles";
import LoginForm from "./LoginForm";

export const metadata = { title: "Entrar" };

export default async function LoginPage() {
  const s = await getSession().catch(() => null);
  if (s) redirect(homeFor(s.role));
  return (
    <main className="grid min-h-[100dvh] lg:grid-cols-[1.1fr_1fr]">
      {/* Panel de marca (solo pantallas grandes) */}
      <section
        aria-hidden
        className="relative hidden overflow-hidden p-10 text-white lg:flex lg:flex-col lg:justify-between"
        style={{ background: "linear-gradient(140deg, var(--hero-from), var(--hero-to))" }}
      >
        <div className="absolute -top-24 -left-24 size-96 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -right-20 bottom-0 size-80 rounded-full bg-fuchsia-300/10 blur-3xl" />
        <p className="relative text-lg font-semibold">Herrajes POS</p>
        <div className="relative max-w-md">
          <p className="font-display text-5xl leading-tight">Cotiza y cobra en segundos.</p>
          <p className="mt-4 text-lg text-white/80">Tiras, tramos, hojas de vidrio y herrajes con el precio correcto, sin hacer cuentas a mano.</p>
        </div>
        <p className="relative text-sm text-white/60">Aluminio · Vidrio · Herrajes</p>
      </section>

      <section className="flex items-center justify-center p-4 sm:p-8">
        <div className="w-full max-w-sm">
          <div className="mb-8 flex items-center gap-3">
            <span className="flex h-11 w-14 items-center justify-center rounded-2xl bg-foreground text-background">
              <svg viewBox="0 0 24 24" className="size-5" aria-hidden fill="currentColor">
                <path d="M5 21V3h3.2v7.3h7.6V3H19v18h-3.2v-7.6H8.2V21z" />
              </svg>
            </span>
            <span className="text-lg font-semibold">Herrajes POS</span>
          </div>
          <h1 className="font-display text-3xl">Bienvenido</h1>
          <p className="mt-1 mb-6 text-muted">Entra con el usuario que te dio el administrador.</p>
          <div className="rounded-3xl bg-surface p-5 shadow-[var(--surface-shadow)] sm:p-6">
            <Suspense>
              <LoginForm />
            </Suspense>
          </div>
        </div>
      </section>
    </main>
  );
}
