import { requirePage } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { Product } from "@/lib/models/Product";
import { getSettings } from "@/lib/models/Settings";
import Pos, { type CategoryInfo } from "@/components/pos/Pos";

export const metadata = { title: "Mostrador" };

export default async function MostradorPage() {
  await requirePage("sales:create");
  await connectDB();
  const [settings, products] = await Promise.all([getSettings(), Product.find({ active: true }).select("category group").lean()]);
  // Cuenta tarjetas (un perfil con varios colores cuenta como uno).
  const seen = new Map<string, Set<string>>();
  for (const p of products) {
    const set = seen.get(p.category) ?? new Set<string>();
    set.add(p.group || String(p._id));
    seen.set(p.category, set);
  }
  const categories: CategoryInfo[] = [...seen.entries()]
    .map(([name, set]) => ({ name, count: set.size }))
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name, "es"));
  return <Pos defaultPct={settings.defaultCommissionPct} categories={categories} />;
}
