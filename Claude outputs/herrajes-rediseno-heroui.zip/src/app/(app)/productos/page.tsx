import Link from "next/link";
import { requirePage } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { Product } from "@/lib/models/Product";
import { can } from "@/lib/roles";
import { escapeRegex } from "@/lib/text";
import { priceSummary } from "@/lib/productSummary";
import { availableModes, UNIT_TYPE_LABELS, type ProductPricing } from "@/lib/pricing";
import { fmtDate } from "@/lib/labels";
import { Badge, PageHeader, btn } from "@/components/ui";
import { UrlSearch, UrlSelect } from "@/components/UrlFilters";

export const metadata = { title: "Productos" };

export default async function ProductosPage({ searchParams }: { searchParams: Promise<{ q?: string; categoria?: string; inactivos?: string }> }) {
  const user = await requirePage("products:view");
  const editor = can(user.role, "products:edit");
  const sp = await searchParams;
  await connectDB();

  const filter: Record<string, unknown> = {};
  if (!(editor && sp.inactivos === "1")) filter.active = true;
  if (sp.categoria) filter.category = sp.categoria;
  if (sp.q?.trim()) {
    filter.$and = sp.q
      .trim()
      .split(/\s+/)
      .map((t) => new RegExp(escapeRegex(t), "i"))
      .map((rx) => ({ $or: [{ name: rx }, { group: rx }, { code: rx }, { category: rx }, { line: rx }, { color: rx }] }));
  }
  const [products, categories] = await Promise.all([
    Product.find(filter).sort({ category: 1, group: 1, name: 1 }).limit(1000).lean(),
    Product.distinct("category", { active: true }),
  ]);

  return (
    <div className="mx-auto max-w-[1400px]">
      <PageHeader title={editor ? "Productos y precios" : "Lista de precios"} subtitle={editor ? "Toca un producto para cambiar su precio." : "Consulta precios por tira, metro, hoja o pieza."}>
        {editor && (
          <>
            <Link href="/productos/nuevo" className={btn()}>
              Nuevo producto
            </Link>
            <Link href="/productos/ajuste" className={btn("secondary")}>
              Subir/bajar precios
            </Link>
            <Link href="/productos/importar" className={btn("secondary")}>
              Importar lista
            </Link>
          </>
        )}
        <a href="/api/products/export" className={btn("ghost")}>
          Descargar CSV
        </a>
      </PageHeader>

      <div className="mb-4 grid grid-cols-1 gap-3 rounded-3xl bg-surface p-4 shadow-[var(--surface-shadow)] sm:grid-cols-[minmax(0,1fr)_14rem] sm:items-end lg:grid-cols-[minmax(0,1fr)_14rem_12rem]">
        <UrlSearch label="Buscar" placeholder="Nombre, código, línea o color" />
        <UrlSelect name="categoria" label="Categoría" options={[{ value: "", label: "Todas" }, ...(categories as string[]).sort().map((c) => ({ value: c, label: c }))]} />
        {editor && (
          <UrlSelect
            name="inactivos"
            label="Mostrar"
            options={[
              { value: "", label: "Activos" },
              { value: "1", label: "Incluir dados de baja" },
            ]}
          />
        )}
      </div>

      <p className="mb-2 text-sm text-muted">{products.length} producto(s){products.length === 1000 ? " — afina la búsqueda para ver más" : ""}</p>
      <ul className="grid grid-cols-1 gap-2 md:grid-cols-2 xl:grid-cols-3">
        {products.map((p) => {
          const body = (
            <>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm text-muted">
                  {p.code} · {p.category}
                </span>
                {!p.active && <Badge tone="bad">De baja</Badge>}
                {p.active && availableModes(p as unknown as ProductPricing).length === 0 && <Badge tone="warn">Sin precio</Badge>}
              </div>
              <p className="font-semibold leading-snug">{p.name}</p>
              {(p.line || p.color) && <p className="text-sm text-muted">{[p.line, p.color].filter(Boolean).join(" · ")}</p>}
              <p className="text-sm text-muted">{UNIT_TYPE_LABELS[p.unitType]}</p>
              <div className="mt-1 text-sm font-medium tabular">
                {priceSummary(p as unknown as ProductPricing).map((s) => (
                  <p key={s}>{s}</p>
                ))}
              </div>
              <p className="mt-auto pt-2 text-sm text-muted">Actualizado {fmtDate(p.updatedAt, false)}</p>
            </>
          );
          return (
            <li key={String(p._id)}>
              {editor ? (
                <Link href={`/productos/${String(p._id)}`} className="flex h-full flex-col rounded-2xl bg-surface p-4 shadow-[var(--surface-shadow)] outline-none transition hover:-translate-y-0.5 hover:shadow-[var(--overlay-shadow)] focus-visible:ring-2 focus-visible:ring-focus">
                  {body}
                </Link>
              ) : (
                <div className="flex h-full flex-col rounded-2xl bg-surface p-4 shadow-[var(--surface-shadow)]">{body}</div>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
