import Link from "next/link";
import { redirect } from "next/navigation";
import { requirePage } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { getSettings } from "@/lib/models/Settings";
import { loadSaleFor } from "@/lib/saleAccess";
import { buildItems } from "@/lib/sales";
import { can } from "@/lib/roles";
import { formatMoney, formatNumber, round2, type CustomerType } from "@/lib/pricing";
import { fmtDate } from "@/lib/labels";
import { Alert, Card, PageHeader, btn } from "@/components/ui";
import ConvertQuote from "@/components/ConvertQuote";
import CancelSale from "@/components/CancelSale";

export const metadata = { title: "Cotización" };

export default async function QuotePage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requirePage("sales:create");
  await connectDB();
  const { id } = await params;
  const [quote, settings] = await Promise.all([loadSaleFor(user, id), getSettings()]);
  if (quote.kind !== "cotizacion" || quote.status !== "vigente") redirect(`/notas/${id}`);

  const expired = !!quote.validUntil && new Date(quote.validUntil).getTime() < Date.now();
  let subtotal = quote.subtotal;
  let repriceError = "";
  if (expired) {
    try {
      const items = await buildItems(
        quote.items.map((it) => ({
          productId: String(it.product),
          mode: it.mode,
          qty: it.qty,
          lengthM: it.lengthM ?? undefined,
          barLengthM: it.barLengthM ?? undefined,
          widthM: it.widthM ?? undefined,
          heightM: it.heightM ?? undefined,
        })),
        (quote.customerType ?? "particular") as CustomerType,
      );
      subtotal = round2(items.reduce((a, i) => a + i.subtotal, 0));
    } catch (e) {
      repriceError = (e as Error).message;
    }
  }
  const canCancel = can(user.role, "sales:viewAll") || String(quote.seller) === user.id;

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader title={`Cotización ${quote.folio}`}>
        <Link href={`/notas/${id}`} className={btn("secondary")}>
          Ver / imprimir
        </Link>
        {canCancel && <CancelSale id={id} label="Cancelar cotización" />}
      </PageHeader>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_360px]">
        <Card>
          <p className="text-muted">
            {fmtDate(quote.createdAt)} · {quote.sellerName}
            {quote.customerName ? ` · ${quote.customerName}` : ""}
          </p>
          <ul className="mt-3 divide-y divide-line">
            {quote.items.map((it, i) => (
              <li key={i} className="flex justify-between gap-3 py-2">
                <div className="min-w-0">
                  <p className="font-semibold">{it.name}</p>
                  <p className="text-sm text-muted">
                    {it.detail} · {formatNumber(it.qty)} × {formatMoney(it.unitPrice)}
                  </p>
                </div>
                <p className="font-semibold tabular">{formatMoney(it.subtotal)}</p>
              </li>
            ))}
          </ul>
          <p className="mt-3 flex justify-between border-t border-line pt-3 text-lg font-bold tabular">
            <span>Subtotal cotizado</span>
            <span>{formatMoney(quote.subtotal)}</span>
          </p>
        </Card>

        <Card>
          <h2 className="font-display mb-3 text-xl font-medium">Convertir en venta</h2>
          {expired ? (
            repriceError ? (
              <Alert>No se puede convertir: {repriceError}. Haz una cotización nueva desde el mostrador.</Alert>
            ) : (
              <>
                <div className="mb-3">
                  <Alert tone="warn">
                    Venció el {fmtDate(quote.validUntil, false)}. Se cobrará con los precios actuales
                    {subtotal !== quote.subtotal ? ` (subtotal nuevo ${formatMoney(subtotal)}).` : " (sin cambios)."}
                  </Alert>
                </div>
                <ConvertQuote id={id} subtotal={subtotal} defaultPct={settings.defaultCommissionPct} />
              </>
            )
          ) : (
            <>
              <p className="mb-3 text-muted">Vigente hasta {fmtDate(quote.validUntil, false)}: se respetan los precios cotizados.</p>
              <ConvertQuote id={id} subtotal={subtotal} defaultPct={settings.defaultCommissionPct} />
            </>
          )}
        </Card>
      </div>
    </div>
  );
}
