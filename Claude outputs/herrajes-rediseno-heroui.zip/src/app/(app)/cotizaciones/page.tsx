import Link from "next/link";
import { requirePage } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { Sale } from "@/lib/models/Sale";
import { plain } from "@/lib/serialize";
import { formatMoney } from "@/lib/pricing";
import { btn } from "@/components/ui";
import SalesTable, { type SaleRow } from "@/components/SalesTable";
import QuoteTicket, { type QuoteTicketData } from "@/components/dash/QuoteTicket";
import { UrlSearch, UrlSelect } from "@/components/UrlFilters";
import Icon from "@/components/Icon";

export const metadata = { title: "Cotizaciones" };

export default async function CotizacionesPage({ searchParams }: { searchParams: Promise<{ estado?: string; q?: string }> }) {
  await requirePage("sales:create");
  const sp = await searchParams;
  await connectDB();
  const estado = sp.estado ?? "vigente";
  const filter: Record<string, unknown> = { kind: "cotizacion" };
  if (["vigente", "convertida", "cancelada"].includes(estado)) filter.status = estado;
  if (sp.q?.trim()) {
    const rx = new RegExp(sp.q.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
    filter.$or = [{ folio: rx }, { customerName: rx }, { customerPhone: rx }];
  }
  const rows = await Sale.find(filter).sort({ createdAt: -1 }).limit(200).lean();
  const pendingTotal = estado === "vigente" ? rows.reduce((a, r) => a + r.total, 0) : 0;

  return (
    <div className="mx-auto flex max-w-[1400px] flex-col gap-4 sm:gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-medium sm:text-4xl">Cotizaciones</h1>
          <p className="mt-1 text-muted">
            {estado === "vigente" && rows.length
              ? `${rows.length} pendiente(s) por ${formatMoney(pendingTotal)}. Toca una para cobrarla.`
              : "Las cotizaciones se cobran en un toque cuando el cliente regresa."}
          </p>
        </div>
        <Link href="/mostrador" className={btn("primary", "max-sm:hidden")}>
          <Icon name="plus" className="size-4" /> Nueva cotización
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-3 rounded-3xl bg-surface p-4 shadow-[var(--surface-shadow)] sm:grid-cols-[minmax(0,1fr)_14rem] sm:items-end">
        <UrlSearch label="Buscar" placeholder="Folio, cliente o teléfono" />
        <UrlSelect
          name="estado"
          label="Estado"
          options={[
            { value: "", label: "Pendientes" },
            { value: "convertida", label: "Cobradas" },
            { value: "cancelada", label: "Canceladas" },
            { value: "todas", label: "Todas" },
          ]}
        />
      </div>

      {estado === "vigente" && rows.length > 0 ? (
        <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2 sm:gap-4 xl:grid-cols-3 2xl:grid-cols-4">
          {plain<QuoteTicketData[]>(rows).map((q) => (
            <li key={q._id}>
              <QuoteTicket q={q} compact />
            </li>
          ))}
        </ul>
      ) : (
        <SalesTable rows={plain<SaleRow[]>(rows)} showSeller quoteMode />
      )}
    </div>
  );
}
