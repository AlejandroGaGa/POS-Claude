import Link from "next/link";
import { requirePage } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { addDays, dayStr, isDayStr } from "@/lib/dates";
import { getPeriodTotal, getStats } from "@/lib/stats";
import { Sale } from "@/lib/models/Sale";
import { Product } from "@/lib/models/Product";
import { availableModes, formatMoney, formatNumber, PAYMENT_LABELS, type PaymentMethod, type ProductPricing } from "@/lib/pricing";
import { plain } from "@/lib/serialize";
import { Card, CardTitle, Stat, btn, cx } from "@/components/ui";
import { DailyColumns, HBars } from "@/components/charts";
import DateRangeFilter from "@/components/DateRangeFilter";
import TopProductsTable from "@/components/dash/TopProductsTable";
import QuoteTicket, { type QuoteTicketData } from "@/components/dash/QuoteTicket";
import Icon from "@/components/Icon";

export const metadata = { title: "Tablero" };

function daysBetween(a: string, b: string) {
  return Math.round((Date.parse(b) - Date.parse(a)) / 86400000) + 1;
}

function greeting() {
  const h = Number(new Intl.DateTimeFormat("en-US", { hour: "numeric", hour12: false, timeZone: process.env.NEXT_PUBLIC_TZ || "America/Mexico_City" }).format(new Date()));
  return h < 12 ? "Buenos días" : h < 19 ? "Buenas tardes" : "Buenas noches";
}

export default async function TableroPage({ searchParams }: { searchParams: Promise<{ desde?: string; hasta?: string }> }) {
  const user = await requirePage("stats:view");
  const sp = await searchParams;
  const today = dayStr();
  const hasta = isDayStr(sp.hasta) ? sp.hasta : today;
  const desde = isDayStr(sp.desde) && sp.desde <= hasta ? sp.desde : addDays(hasta, -29);
  const n = daysBetween(desde, hasta);
  await connectDB();

  const [st, prevTotal, pendingQuotes, products] = await Promise.all([
    getStats(desde, hasta),
    getPeriodTotal(addDays(desde, -n), addDays(desde, -1)),
    Sale.find({ kind: "cotizacion", status: "vigente" }).sort({ createdAt: -1 }).limit(4).lean(),
    Product.find({ active: true }).select("unitType price pricePerMeter bars pricePerM2 pricePerM2Vidriero sheets").lean(),
  ]);
  const noPrice = products.filter((p) => availableModes(p as unknown as ProductPricing).length === 0).length;
  const delta = prevTotal > 0 ? ((st.total - prevTotal) / prevTotal) * 100 : null;

  // Días sin ventas también se grafican para que la serie sea continua.
  const map = new Map(st.byDay.map((d) => [d._id, d]));
  const days: { day: string; total: number; count: number }[] = [];
  for (let d = desde, i = 0; d <= hasta && i < 400; d = addDays(d, 1), i++) days.push({ day: d, total: map.get(d)?.total ?? 0, count: map.get(d)?.count ?? 0 });

  const top = st.topProducts[0];
  const firstName = user.name.split(" ")[0];

  return (
    <div className="mx-auto flex max-w-[1400px] flex-col gap-4 sm:gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-medium sm:text-4xl">Tablero</h1>
          <p className="mt-1 text-muted">
            {greeting()}, {firstName}. Así va el negocio.
          </p>
        </div>
        <Link href="/mostrador" className={btn("primary", "max-sm:hidden")}>
          <Icon name="plus" className="size-4" /> Nueva venta
        </Link>
      </div>

      <DateRangeFilter desde={desde} hasta={hasta} label="Periodo del tablero" />

      {/* Resumen del periodo (banner oscuro) */}
      <section
        aria-label="Resumen del periodo"
        className="relative overflow-hidden rounded-3xl p-5 text-white sm:p-6"
        style={{ background: "linear-gradient(120deg, var(--hero-from), var(--hero-to))" }}
      >
        <div aria-hidden className="pointer-events-none absolute -top-16 -right-10 size-56 rounded-full bg-white/10 blur-3xl" />
        <div className="relative flex items-center justify-between gap-3">
          <p className="font-display flex items-center gap-2 text-lg">
            <Icon name="sparkles" className="size-5" /> Resumen del periodo
          </p>
          <p className="text-sm text-white/70">{n === 1 ? "1 día" : `${n} días`}</p>
        </div>
        <p className="relative mt-3 max-w-4xl text-[17px] leading-relaxed text-white/90">
          Llevas <strong className="text-white">{formatMoney(st.total)}</strong> en {st.count} venta(s)
          {delta !== null && (
            <>
              {", "}
              <span className={cx("font-semibold", delta >= 0 ? "text-emerald-300" : "text-rose-300")}>
                {delta >= 0 ? "▲" : "▼"} {formatNumber(Math.abs(delta), 0)}%
              </span>{" "}
              contra el periodo anterior
            </>
          )}
          .{top && (
            <>
              {" "}
              Lo que más deja es <span className="font-semibold text-amber-200">{top.name}</span>.
            </>
          )}{" "}
          {st.quotes.pending > 0 ? `Tienes ${st.quotes.pending} cotización(es) por cobrar.` : "No hay cotizaciones pendientes."}
          {noPrice > 0 && ` ${noPrice} producto(s) siguen sin precio.`}
        </p>
      </section>

      {/* Indicadores */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
        <Stat
          label="Vendido"
          value={formatMoney(st.total)}
          emphasis
          className="col-span-2 sm:col-span-1"
          hint={
            delta !== null ? (
              <span className={cx("inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-medium", delta >= 0 ? "bg-success-soft text-success-soft-foreground" : "bg-danger-soft text-danger-soft-foreground")}>
                <Icon name={delta >= 0 ? "up" : "down"} className="size-3.5" />
                {formatNumber(Math.abs(delta), 0)}% vs. anterior
              </span>
            ) : (
              "Sin periodo anterior para comparar"
            )
          }
        />
        <Stat label="Ventas" value={formatNumber(st.count)} hint={st.cancelled ? `${st.cancelled} cancelada(s)` : "Sin cancelaciones"} />
        <Stat label="Ticket promedio" value={formatMoney(st.avg)} />
        <Stat
          label="Cotizaciones cobradas"
          value={`${formatNumber(st.quotes.rate * 100, 0)}%`}
          hint={`${st.quotes.converted} de ${st.quotes.count}`}
          className="col-span-2 sm:col-span-1"
        />
      </div>

      <div className="grid grid-cols-1 gap-4 sm:gap-5 xl:grid-cols-[minmax(0,1fr)_380px]">
        <div className="flex min-w-0 flex-col gap-4 sm:gap-5">
          <Card>
            <div className="mb-4 flex items-baseline justify-between gap-2">
              <CardTitle>Ventas por día</CardTitle>
              <span className="hidden text-sm text-muted sm:inline">Pasa el cursor por una barra para ver el detalle</span>
            </div>
            <DailyColumns days={days} />
          </Card>

          <Card>
            <div className="mb-3 flex items-baseline justify-between gap-2">
              <CardTitle>Productos más vendidos</CardTitle>
              <Link href={`/ventas?desde=${desde}&hasta=${hasta}`} className="text-sm font-medium text-accent underline-offset-4 hover:underline">
                Ver ventas
              </Link>
            </div>
            <TopProductsTable rows={st.topProducts} grandTotal={st.byCategory.reduce((a, c) => a + c.total, 0)} />
          </Card>

          <div className="grid grid-cols-1 gap-4 sm:gap-5 lg:grid-cols-2">
            <Card>
              <CardTitle className="mb-4">Por método de pago</CardTitle>
              <HBars
                label="Ventas por método de pago"
                rows={st.byMethod.map((m) => ({
                  name: PAYMENT_LABELS[m._id as PaymentMethod] ?? m._id,
                  value: m.total,
                  extra: `${m.count} venta(s)${m.commission ? ` · comisión ${formatMoney(m.commission)}` : ""}`,
                }))}
              />
              {st.commission > 0 && <p className="mt-4 text-sm text-muted">Comisiones de terminal cobradas: {formatMoney(st.commission)}</p>}
            </Card>
            <Card>
              <CardTitle className="mb-4">Por vendedor</CardTitle>
              <HBars label="Ventas por vendedor" rows={st.bySeller.map((s) => ({ name: s._id || "—", value: s.total, extra: `${s.count} venta(s)` }))} />
            </Card>
          </div>
        </div>

        {/* Rail de cotizaciones pendientes */}
        <aside aria-label="Cotizaciones pendientes" className="flex flex-col gap-3 rounded-3xl bg-surface p-4 shadow-[var(--surface-shadow)] sm:p-5 xl:sticky xl:top-3 xl:self-start">
          <div className="flex items-center justify-between">
            <CardTitle>Por cobrar</CardTitle>
            <Link href="/mostrador" aria-label="Nueva cotización" className="flex size-10 items-center justify-center rounded-full hover:bg-default">
              <Icon name="plus" />
            </Link>
          </div>
          {pendingQuotes.length === 0 ? (
            <p className="rounded-2xl bg-surface-secondary p-6 text-center text-muted">No hay cotizaciones pendientes.</p>
          ) : (
            plain<QuoteTicketData[]>(pendingQuotes).map((q) => <QuoteTicket key={q._id} q={q} compact />)
          )}
          <Link href="/cotizaciones" className={btn("secondary", "w-full")}>
            Ver todas las cotizaciones
          </Link>
          <div className="mt-2 border-t border-separator pt-4">
            <CardTitle as="h3" className="mb-3 text-lg sm:text-xl">
              Por categoría
            </CardTitle>
            <HBars label="Ventas por categoría" rows={st.byCategory.map((c) => ({ name: c._id || "Sin categoría", value: c.total }))} />
          </div>
        </aside>
      </div>
    </div>
  );
}
