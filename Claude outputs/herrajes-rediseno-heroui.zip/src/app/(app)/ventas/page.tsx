import Link from "next/link";
import { Types } from "mongoose";
import { requirePage } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { Sale } from "@/lib/models/Sale";
import { User } from "@/lib/models/User";
import { can } from "@/lib/roles";
import { dayStr, isDayStr, range } from "@/lib/dates";
import { formatMoney, PAYMENT_LABELS, PAYMENT_METHODS } from "@/lib/pricing";
import { plain } from "@/lib/serialize";
import { Stat, btn } from "@/components/ui";
import DateRangeFilter from "@/components/DateRangeFilter";
import { UrlSearch, UrlSelect } from "@/components/UrlFilters";
import Icon from "@/components/Icon";
import SalesTable, { type SaleRow } from "@/components/SalesTable";

export const metadata = { title: "Ventas" };

type SP = { desde?: string; hasta?: string; pago?: string; vendedor?: string; estado?: string; q?: string };

export default async function VentasPage({ searchParams }: { searchParams: Promise<SP> }) {
  const user = await requirePage("sales:create");
  const viewAll = can(user.role, "sales:viewAll");
  const sp = await searchParams;
  const today = dayStr();
  const desde = isDayStr(sp.desde) ? sp.desde : today;
  const hasta = isDayStr(sp.hasta) ? sp.hasta : desde > today ? desde : today;

  await connectDB();
  const filter: Record<string, unknown> = { kind: "venta", createdAt: range(desde, hasta) };
  if (!viewAll) filter.seller = new Types.ObjectId(user.id);
  else if (sp.vendedor && Types.ObjectId.isValid(sp.vendedor)) filter.seller = new Types.ObjectId(sp.vendedor);
  if (sp.pago && (PAYMENT_METHODS as readonly string[]).includes(sp.pago)) filter.paymentMethod = sp.pago;
  if (sp.estado === "cancelada") filter.status = "cancelada";
  else if (sp.estado !== "todas") filter.status = { $ne: "cancelada" };
  if (sp.q?.trim()) {
    const rx = new RegExp(sp.q.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
    filter.$or = [{ folio: rx }, { customerName: rx }, { customerPhone: rx }];
  }

  const [rows, sellers] = await Promise.all([
    Sale.find(filter).sort({ createdAt: -1 }).limit(300).lean(),
    viewAll ? User.find().select("name").sort({ name: 1 }).lean() : Promise.resolve([]),
  ]);
  const valid = rows.filter((r) => r.status !== "cancelada");
  const sum = (arr: typeof rows) => arr.reduce((a, r) => a + r.total, 0);
  const byMethod = PAYMENT_METHODS.map((m) => ({ m, total: sum(valid.filter((r) => r.paymentMethod === m)) }));

  const payOpts = [{ value: "", label: "Todos" }, ...PAYMENT_METHODS.map((m) => ({ value: m, label: PAYMENT_LABELS[m] }))];
  const sellerOpts = [{ value: "", label: "Todos" }, ...sellers.map((x) => ({ value: String(x._id), label: x.name }))];
  const statusOpts = [
    { value: "", label: "Pagadas" },
    { value: "cancelada", label: "Canceladas" },
    { value: "todas", label: "Todas" },
  ];

  return (
    <div className="mx-auto flex max-w-[1400px] flex-col gap-4 sm:gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-medium sm:text-4xl">{viewAll ? "Ventas" : "Mis ventas"}</h1>
          <p className="mt-1 text-muted">Toca una venta para ver o imprimir su nota.</p>
        </div>
        <Link href="/mostrador" className={btn("primary", "max-sm:hidden")}>
          <Icon name="plus" className="size-4" /> Nueva venta
        </Link>
      </div>

      <DateRangeFilter desde={desde} hasta={hasta} label="Periodo de ventas" />

      <div className="grid grid-cols-2 gap-3 rounded-3xl bg-surface p-4 shadow-[var(--surface-shadow)] md:grid-cols-4 md:items-end">
        <UrlSearch label="Buscar" placeholder="Folio, cliente o teléfono" className="col-span-2 md:col-span-1" />
        <UrlSelect name="pago" label="Pago" options={payOpts} />
        <UrlSelect name="estado" label="Estado" options={statusOpts} />
        {viewAll && <UrlSelect name="vendedor" label="Vendedor" options={sellerOpts} className="col-span-2 md:col-span-1" />}
      </div>

      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-5">
        <Stat label="Total" value={formatMoney(sum(valid))} emphasis className="col-span-2 lg:col-span-1" />
        <Stat label="Ventas" value={String(valid.length)} />
        {byMethod.map((b) => (
          <Stat key={b.m} label={PAYMENT_LABELS[b.m]} value={formatMoney(b.total)} />
        ))}
      </div>

      <SalesTable rows={plain<SaleRow[]>(rows)} showSeller={viewAll} />
      {rows.length === 300 && <p className="text-sm text-muted">Se muestran las 300 más recientes; acota las fechas para ver el resto.</p>}
    </div>
  );
}
