import { requirePage } from "@/lib/auth";
import { can } from "@/lib/roles";
import Shell, { type NavItem } from "@/components/Shell";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await requirePage();
  const nav: NavItem[] = [
    can(user.role, "stats:view") && { href: "/tablero", label: "Tablero", short: "Inicio", icon: "chart", section: "General" },
    { href: "/mostrador", label: "Mostrador", short: "Vender", icon: "cart", section: "General", primary: true },
    { href: "/cotizaciones", label: "Cotizaciones", short: "Cotizar", icon: "doc", section: "General", primary: true },
    { href: "/ventas", label: can(user.role, "sales:viewAll") ? "Ventas" : "Mis ventas", short: "Ventas", icon: "cash", section: "General", primary: true },
    { href: "/productos", label: can(user.role, "products:edit") ? "Productos y precios" : "Lista de precios", short: "Precios", icon: "box", section: "Gestión", primary: true },
    can(user.role, "users:manage") && { href: "/usuarios", label: "Usuarios", short: "Usuarios", icon: "users", section: "Gestión" },
    can(user.role, "settings:edit") && { href: "/ajustes", label: "Ajustes", short: "Ajustes", icon: "gear", section: "Otros" },
  ].filter(Boolean) as NavItem[];

  return (
    <Shell user={user} nav={nav}>
      {children}
    </Shell>
  );
}
